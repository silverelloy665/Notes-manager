-- EXPERIMENT 1: DDL & DML OPERATIONS
-- Aim: To create normalized university database tables and perform data manipulation operations.

CREATE TABLE Department (
    dept_id INT PRIMARY KEY,
    dept_name VARCHAR(50) NOT NULL,
    building VARCHAR(30)
);

CREATE TABLE Student (
    student_id INT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    dept_id INT,
    FOREIGN KEY (dept_id) REFERENCES Department(dept_id) ON DELETE CASCADE
);

INSERT INTO Department VALUES (1, 'Computer Science', 'Turing Hall');
INSERT INTO Department VALUES (2, 'Information Tech', 'Shannon Wing');

INSERT INTO Student VALUES (101, 'Aarush Mishra', 'aarush@college.edu', 1);
INSERT INTO Student VALUES (102, 'Priya Patel', 'priya@college.edu', 1);

SELECT s.name, d.dept_name, d.building
FROM Student s
JOIN Department d ON s.dept_id = d.dept_id;