-- EXPERIMENT 2: JOINS, SUBQUERIES AND AGGREGATES
-- Aim: Execute multi-table inner/outer joins, GROUP BY aggregations and subqueries.

SELECT d.dept_name, COUNT(s.student_id) AS student_count
FROM Department d
LEFT JOIN Student s ON d.dept_id = s.dept_id
GROUP BY d.dept_id, d.dept_name
HAVING COUNT(s.student_id) >= 1;

SELECT name, email
FROM Student
WHERE dept_id IN (
    SELECT dept_id FROM Department WHERE building = 'Turing Hall'
);