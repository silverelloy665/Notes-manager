// EXPERIMENT 2: RESTful API CONTROLLER IN NODE.JS
// Aim: Construct an Express server providing CRUD endpoints with status codes.
const express = require('express');
const app = express();
app.use(express.json());

let notes = [
    { id: 1, topic: 'DBMS', title: 'ACID Properties' },
    { id: 2, topic: 'DAA', title: 'Divide and Conquer' }
];

app.get('/api/notes', (req, res) => {
    res.status(200).json({ success: true, count: notes.length, data: notes });
});

app.post('/api/notes', (req, res) => {
    const { topic, title } = req.body;
    if (!topic || !title) return res.status(400).json({ error: 'Missing required fields' });
    const newNote = { id: notes.length + 1, topic, title };
    notes.push(newNote);
    res.status(201).json({ success: true, data: newNote });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));