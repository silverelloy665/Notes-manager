// EXPERIMENT 3: 0-1 KNAPSACK USING DYNAMIC PROGRAMMING
// Aim: Solve the 0-1 Knapsack problem using dynamic programming memoization table.
#include <iostream>
#include <vector>
using namespace std;

int knapsackDP(int W, const vector<int>& wt, const vector<int>& val, int n) {
    vector<vector<int>> dp(n + 1, vector<int>(W + 1, 0));
    for (int i = 1; i <= n; i++) {
        for (int w = 0; w <= W; w++) {
            if (wt[i - 1] <= w) {
                dp[i][w] = max(val[i - 1] + dp[i - 1][w - wt[i - 1]], dp[i - 1][w]);
            } else {
                dp[i][w] = dp[i - 1][w];
            }
        }
    }
    return dp[n][W];
}

int main() {
    vector<int> val = {60, 100, 120};
    vector<int> wt = {10, 20, 30};
    int W = 50;
    cout << "Maximum Value in Knapsack: " << knapsackDP(W, wt, val, val.size()) << endl;
    return 0;
}