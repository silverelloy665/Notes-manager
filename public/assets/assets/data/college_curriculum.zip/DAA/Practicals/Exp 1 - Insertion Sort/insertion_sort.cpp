// EXPERIMENT 1: INSERTION SORT
// Aim: Implement Insertion Sort and verify best-case O(n) and worst-case O(n^2) performance.
#include <iostream>
#include <vector>
using namespace std;

void insertionSort(vector<int>& arr) {
    int n = arr.size();
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

int main() {
    vector<int> data = {64, 25, 12, 22, 11};
    cout << "Original Array: ";
    for (int x : data) cout << x << " ";
    cout << endl;

    insertionSort(data);

    cout << "Sorted Array: ";
    for (int x : data) cout << x << " ";
    cout << endl;
    return 0;
}