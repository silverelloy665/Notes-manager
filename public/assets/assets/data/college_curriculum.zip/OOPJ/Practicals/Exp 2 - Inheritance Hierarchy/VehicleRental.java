// EXPERIMENT 2: INHERITANCE & METHOD OVERRIDING
// Aim: Demonstrate class inheritance, super constructors, and method overriding.
class Vehicle {
    protected String registrationNumber;
    protected double baseDailyRate;

    public Vehicle(String reg, double rate) {
        this.registrationNumber = reg;
        this.baseDailyRate = rate;
    }

    public double calculateRent(int days) {
        return baseDailyRate * days;
    }
}

class Car extends Vehicle {
    private int seatingCapacity;

    public Car(String reg, double rate, int seats) {
        super(reg, rate);
        this.seatingCapacity = seats;
    }

    @Override
    public double calculateRent(int days) {
        double total = super.calculateRent(days);
        if (seatingCapacity > 5) total += 500 * days;
        return total;
    }
}

public class VehicleRental {
    public static void main(String[] args) {
        Car sedan = new Car("MH-02-CD-1234", 1200.0, 7);
        System.out.println("Total Rent for 3 Days: INR " + sedan.calculateRent(3));
    }
}