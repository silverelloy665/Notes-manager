// EXPERIMENT 1: JAVA CONSOLE I/O & OBJECT MODELING
// Aim: Implement a robust student details console reader with Scanner and encapsulation.
import java.util.Scanner;

public class StudentConsole {
    private String name;
    private String studentId;
    private double marks;

    public StudentConsole(String name, String studentId, double marks) {
        this.name = name;
        this.studentId = studentId;
        this.marks = marks;
    }

    public void displayProfile() {
        System.out.println("=== Student Academic Record ===");
        System.out.println("ID: " + studentId);
        System.out.println("Name: " + name);
        System.out.println("Marks: " + marks + " / 100");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Student Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Student ID: ");
        String id = sc.nextLine();
        System.out.print("Enter Marks Obtained: ");
        double marks = sc.nextDouble();

        StudentConsole s = new StudentConsole(name, id, marks);
        s.displayProfile();
        sc.close();
    }
}