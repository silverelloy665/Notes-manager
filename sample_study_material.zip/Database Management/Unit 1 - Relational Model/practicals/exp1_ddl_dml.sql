-- SQL DDL and DML Practical
CREATE TABLE Students (
    student_id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE
);

INSERT INTO Students VALUES (1, "Aarush", "aarush@test.com");
SELECT * FROM Students;