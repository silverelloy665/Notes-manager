-- Transaction Control Commands
BEGIN TRANSACTION;
UPDATE Accounts SET balance = balance - 500 WHERE id = 101;
UPDATE Accounts SET balance = balance + 500 WHERE id = 102;
COMMIT;