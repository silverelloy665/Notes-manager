# ACID Properties in DBMS

1. **Atomicity**: All or nothing execution.
2. **Consistency**: Database invariants preserved.
3. **Isolation**: Concurrent transactions execute as if serialized.
4. **Durability**: Committed changes persist across system crashes.