# Virtual Memory & Paging

- **Paging**: Fixed-size memory blocks (pages and frames).
- **Segmentation**: Variable-size logical blocks.
- **Page Fault**: Interrupt generated when a requested page is not in physical RAM.