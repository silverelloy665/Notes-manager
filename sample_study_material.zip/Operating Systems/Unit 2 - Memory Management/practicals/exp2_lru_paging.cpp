#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

int main() {
    cout << "LRU Page Replacement Algorithm Simulation\n";
    return 0;
}